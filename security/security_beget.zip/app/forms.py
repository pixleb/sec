from django import forms

class UserForm(forms.Form):
    username = forms.CharField(label = 'Логин', max_length = 64)
    password = forms.CharField(label = 'Пароль', max_length = 64)
    

class ObjectForm(forms.Form):
    name = forms.CharField(label = 'Название объекта', max_length = 128)
    
