from django.db import models
from django.contrib.auth.models import User

class SecObject(models.Model):
    name = models.CharField(max_length = 128)

class UserMisc(models.Model):
    owner = models.OneToOneField(User, on_delete=models.CASCADE)
    role = models.CharField(max_length = 16, default = 'user')
    obj = models.ForeignKey(SecObject, on_delete = models.CASCADE)

    