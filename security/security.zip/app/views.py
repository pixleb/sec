# django imports
from django.shortcuts import render
from django.http import HttpResponse, HttpResponseRedirect

from django.contrib.auth import login, logout, authenticate
from django.contrib.auth.models import User

from .models import UserMisc, SecObject
from .forms import UserForm, ObjectForm


# auth

def auth(request):
    if request.method == 'POST':
        form = UserForm(request.POST)
        
        if form.is_valid():
            username = form.cleaned_data['username']
            password = form.cleaned_data['password']
        
            user = authenticate(request, username=username, password=password)
            
            if user is not None:
                login(request, user)
                print('logged in as', user.username)
                
                userdata = UserMisc.objects.filter(owner = user)
                print('userdata', userdata, len(userdata))
                if not len(userdata):
                    newdata = UserMisc(owner = user)
                    newdata.save()
                    print('new usermisc created')
                
                return HttpResponseRedirect('/')
            else: return render(request, 'auth_invalid.html', { 'form': form })

        else:
            form = UserForm()
            return render(request, 'auth_invalid.html', { 'form': form })
        
    else: 
        form = UserForm()
        return render(request, 'auth.html', { 'form': form })
    

def logout_user(request):
    logout(request)
    return HttpResponseRedirect('/auth/')


# main


def index(request):
    if not request.user.is_authenticated: return HttpResponseRedirect('/auth/')
    
    user = request.user
    
    userdata = UserMisc.objects.filter(owner = user)
    if not len(userdata): return HttpResponseRedirect('/auth/')
    data = userdata.first()
    
    if data.role == 'super': 
        objects = SecObject.objects.all()
        return render(request, 'index.html', { 'role': data.role, 'objects': objects })
    
    elif data.role == 'admin': 
        obj = data.obj
        users: list = list()
        miscquery = UserMisc.objects.filter(obj = obj, role = 'user')
        for each_misc in miscquery: users.append(each_misc.owner)
        
        return render(request, 'index.html', { 'role': data.role, 'obj': data.obj, 'users': users })
    
    elif data.role == 'user': 
        return render(request, 'index.html', { 'role': data.role, 'obj': data.obj })
    
    else: return HttpResponse('role is incorrect.')
    

def open_obj(request, obj):
    user = request.user
    role = UserMisc.objects.filter(owner = user).first().role
    
    if not user.is_authenticated or role != 'super': return HttpResponseRedirect('/auth/')
    
    obj = SecObject.objects.get(pk = obj)
    
    admins: list = list()
    miscquery = UserMisc.objects.filter(obj = obj, role = 'admin')
    for each_misc in miscquery: admins.append(each_misc.owner)
        
    return render(request, 'obj.html', { 'obj': obj, 'admins': admins })
    
def create_admin(request, obj):
    user = request.user
    role = UserMisc.objects.filter(owner = user).first().role
    
    if not user.is_authenticated or role != 'super': return HttpResponseRedirect('/auth/')
    
    if request.method == 'POST':
        form = UserForm(request.POST)
        
        if form.is_valid():
            username = form.cleaned_data['username']
            password = form.cleaned_data['password']
            
            secobj = SecObject.objects.get(pk = obj)
            if secobj is None: return HttpResponse('Ошибка. Данный объект не найден.')
            
            user = User.objects.create_user(username = username, email = username, password = password)
            user.save()
            
            if user is not None:
                newdata = UserMisc(owner = user, role = 'admin', obj = secobj)
                newdata.save()
                print('new usermisc created')
                
                return HttpResponseRedirect(f'/obj/{obj}/')
            
            else: return HttpResponse('Ошибка. Проверьте введенные данные и обратитесь к разработчику.')
        else: return HttpResponse('Ошибка. Проверьте введенные данные и обратитесь к разработчику.')
    else: return render(request, 'create_admin.html', { 'form': UserForm() })
    
def create_object(request):
    user = request.user
    role = UserMisc.objects.filter(owner = user).first().role
    
    if not user.is_authenticated or role != 'super': return HttpResponseRedirect('/auth/')  
    
    if request.method == 'POST':
        form = ObjectForm(request.POST)
        
        if form.is_valid():
            name = form.cleaned_data['name']
            
            secobj = SecObject(name = name)
            secobj.save()
            
            return HttpResponseRedirect('/')

        else: return HttpResponse('Ошибка. Проверьте введенные данные и обратитесь к разработчику.')
    else: return render(request, 'create_object.html', { 'form': ObjectForm() })

    
def create_user(request, obj):
    user = request.user
    role = UserMisc.objects.filter(owner = user).first().role
    
    if not user.is_authenticated or role != 'admin': return HttpResponseRedirect('/auth/')
    
    if request.method == 'POST':
        form = UserForm(request.POST)
        
        if form.is_valid():
            username = form.cleaned_data['username']
            password = form.cleaned_data['password']
            
            secobj = SecObject.objects.get(pk = obj)
            if secobj is None: return HttpResponse('Ошибка. Данный объект не найден.')
            
            user = User.objects.create_user(username = username, email = username, password = password)
            user.save()
            
            if user is not None:
                newdata = UserMisc(owner = user, role = 'user', obj = secobj)
                newdata.save()
                print('new usermisc created')
                
                return HttpResponseRedirect('/')
            
            else: return HttpResponse('Ошибка. Проверьте введенные данные и обратитесь к разработчику.')
        else: return HttpResponse('Ошибка. Проверьте введенные данные и обратитесь к разработчику.')  
    else: return render(request, 'create_user.html', { 'form': UserForm() })
    

    
    
    
def form(request):
    if request.method == 'GET': 
        ordered = request.GET.get('ordered', '0')
        if ordered.isnumeric(): ordered = int(ordered)
        else: ordered = 0
        return render(request, 'form.html', { 'ordered': ordered })
    elif request.method == 'POST':
        text = 'Новый запрос.\nАдрес: {0}\nОбъем поставки: {1}\nТелефон: {2}'.format(
            request.POST['address'],
            request.POST['mass'],
            request.POST['phone'],
        )
        
        msg = MIMEMultipart()
        msg['From'] = sender
        msg['To'] = receiver
        msg['Subject'] = subject
        
        msg.attach(MIMEText(text))
            
        # python 3.8+
        #asyncio.run(sendMsg(msg))
        # python 3.6 compatible
        loop = asyncio.new_event_loop()
        loop.run_until_complete(sendMsg(msg))
        
        return HttpResponseRedirect('/form?ordered=1')
# tls
async def sendMsg(msg):
    server = smtplib.SMTP(host = 'smtp-mail.outlook.com', port = 587)
    server.starttls()
    server.login(sender, pswd)
    server.sendmail(sender, receiver, msg.as_string())
    server.close()       
'''
# ssl
async def sendMsg(msg):
    server = smtplib.SMTP_SSL(host = 'smtp.beget.ru', port = 465)
    #server.starttls()
    server.login(sender, pswd)
    server.sendmail(sender, receiver, msg.as_string())
    server.close()   
'''
