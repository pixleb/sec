from django.contrib import admin
from django.urls import path

from django.views.generic import TemplateView

import app.views as app

urlpatterns = [
    path('admin/', admin.site.urls),
    
    path('', app.index),
    
    path('auth/', app.auth),
    path('logout/', app.logout_user),
    
    path('obj/<int:obj>/', app.open_obj),
    
    path('create_admin/<int:obj>/', app.create_admin),
    path('create_user/<int:obj>/', app.create_user),
    path('create_object/', app.create_object),
]
